<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Form processor and template renderer class.
 *
 * @package    local_contactform
 * @copyright  2026 Mr Waseem <waseemuxui@gmail.com> (https://sitefixstudio.com)
 * @author     Mr Waseem | WhatsApp: +923341122126
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_contactform;

defined('MOODLE_INTERNAL') || die();

class processor {

    /**
     * Resolve the recipient user object for Moodle's email_to_user().
     *
     * @return \stdClass
     */
    public static function get_recipient(): \stdClass {
        global $CFG;

        $admin = get_admin();
        $customemail = get_config('local_contactform', 'recipientemail');

        if (!empty($customemail) && validate_email($customemail)) {
            $recipient = clone($admin);
            $recipient->email = $customemail;
            return $recipient;
        }

        if (!empty($CFG->supportemail) && validate_email($CFG->supportemail)) {
            $recipient = clone($admin);
            $recipient->email = $CFG->supportemail;
            if (!empty($CFG->supportname)) {
                $recipient->firstname = $CFG->supportname;
                $recipient->lastname = '';
            }
            return $recipient;
        }

        return $admin;
    }

    /**
     * Process POST data and send the email.
     *
     * @param array $postdata
     * @return bool
     */
    public static function send_submission(array $postdata): bool {
        global $USER, $SITE;

        // Honeypot spam check.
        if (!empty($postdata['website_hp'])) {
            return true;
        }

        $recipient = self::get_recipient();

        if (isloggedin() && !isguestuser()) {
            $sendername  = fullname($USER);
            $senderemail = $USER->email;
        } else {
            $sendername  = clean_param($postdata['name'] ?? 'Guest', PARAM_TEXT);
            $senderemail = clean_param($postdata['email'] ?? '', PARAM_EMAIL);
        }

        $subject = clean_param($postdata['subject'] ?? 'General Inquiry', PARAM_TEXT);
        if (!empty($postdata['specific_subject'])) {
            $subject .= ' - ' . clean_param($postdata['specific_subject'], PARAM_TEXT);
        }

        $fullsubject = get_string('emailsubjectprefix', 'local_contactform', $SITE->shortname) . $subject;

        $excludedkeys = ['sesskey', 'website_hp', 'returnurl', 'submit', 'embed', 'type'];
        $linesplain = [];
        $primarycolor = get_config('local_contactform', 'primarycolor') ?: '#0f6cbf';

        $lineshtml = [
            '<div style="font-family:sans-serif; max-width:600px; border:1px solid #e2e8f0; border-radius:8px; overflow:hidden;">',
            '<div style="background:' . s($primarycolor) . '; color:#ffffff; padding:14px 20px; font-size:16px; font-weight:bold;">' . s($fullsubject) . '</div>',
            '<table border="0" cellpadding="10" cellspacing="0" width="100%" style="border-collapse:collapse;">'
        ];

        $linesplain[] = "Submitted by: {$sendername} ({$senderemail})";
        $lineshtml[]  = '<tr style="border-bottom:1px solid #f1f5f9;"><td width="35%" style="font-weight:bold; color:#475569;">Submitted by</td><td>' . s($sendername) . ' (' . s($senderemail) . ')</td></tr>';

        foreach ($postdata as $key => $value) {
            if (in_array($key, $excludedkeys)) {
                continue;
            }
            $cleanlabel = ucfirst(str_replace('_', ' ', clean_param($key, PARAM_ALPHANUMEXT)));
            $cleanval   = clean_param($value, PARAM_TEXT);

            $linesplain[] = "{$cleanlabel}: {$cleanval}";
            $lineshtml[]  = '<tr style="border-bottom:1px solid #f1f5f9;"><td style="font-weight:bold; color:#475569;">' . s($cleanlabel) . '</td><td>' . nl2br(s($cleanval)) . '</td></tr>';
        }

        $lineshtml[] = '</table></div>';

        $messagetext = implode("

", $linesplain);
        $messagehtml = implode("", $lineshtml);

        $fromuser = clone($recipient);
        if (!empty($senderemail) && validate_email($senderemail)) {
            $fromuser->email = $senderemail;
            $fromuser->firstname = $sendername;
            $fromuser->lastname = '';
        }

        return email_to_user($recipient, $fromuser, $fullsubject, $messagetext, $messagehtml);
    }

    /**
     * Render one of the 5 pre-built FontAwesome-enabled form templates.
     *
     * @param string $type ('contactus', 'quickquestion', 'courserequest', 'support', 'checkin')
     * @param string $returnurl
     * @return string HTML markup
     */
    public static function render_template(string $type, string $returnurl = ''): string {
        global $CFG, $COURSE;

        $action = (new \moodle_url('/local/contactform/index.php'))->out(false);
        $sesskey = sesskey();
        $returnurl = $returnurl ?: qualified_me();
        $coursename = !empty($COURSE->fullname) ? format_string($COURSE->fullname) : format_string($CFG->fullname);

        switch ($type) {
            case 'quickquestion':
                if (!isloggedin() || isguestuser()) {
                    return '<div class="alert alert-warning"><i class="fa fa-lock fa-solid"></i> ' . get_string('loginrequired_form', 'local_contactform') . '</div>';
                }
                return '
                <div class="lcf-card">
                    <div class="lcf-card-header">
                        <i class="fa fa-circle-question fa-question-circle"></i>
                        <h3 class="lcf-card-title">Quick Question</h3>
                    </div>
                    <form action="' . s($action) . '" method="post" class="lcf-form">
                        <input type="hidden" name="sesskey" value="' . s($sesskey) . '">
                        <input type="hidden" name="returnurl" value="' . s($returnurl) . '">
                        <input type="hidden" name="course" value="' . s($coursename) . '">
                        <input type="hidden" name="website_hp" value="">
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="qq_subject"><i class="fa fa-tag"></i> Subject *</label>
                            <div class="lcf-input-wrapper">
                                <i class="fa fa-heading lcf-input-icon"></i>
                                <input type="text" id="qq_subject" name="subject" class="lcf-control" placeholder="Enter question topic" required>
                            </div>
                        </div>
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="qq_message"><i class="fa fa-comment-dots"></i> Message *</label>
                            <textarea id="qq_message" name="message" rows="4" class="lcf-control lcf-textarea" placeholder="Type your question here..." required></textarea>
                        </div>
                        <button type="submit" class="lcf-btn"><i class="fa fa-paper-plane"></i> Ask Question</button>
                    </form>
                </div>';

            case 'courserequest':
                return '
                <div class="lcf-card">
                    <div class="lcf-card-header">
                        <i class="fa fa-graduation-cap"></i>
                        <h3 class="lcf-card-title">Course Request</h3>
                    </div>
                    <form action="' . s($action) . '" method="post" class="lcf-form">
                        <input type="hidden" name="sesskey" value="' . s($sesskey) . '">
                        <input type="hidden" name="returnurl" value="' . s($returnurl) . '">
                        <input type="hidden" name="subject" value="Course Request">
                        <input type="hidden" name="website_hp" value="">
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="cr_name"><i class="fa fa-user"></i> Name *</label>
                            <div class="lcf-input-wrapper">
                                <i class="fa fa-user lcf-input-icon"></i>
                                <input type="text" id="cr_name" name="name" class="lcf-control" placeholder="Your full name" required>
                            </div>
                        </div>
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="cr_email"><i class="fa fa-envelope"></i> Email Address *</label>
                            <div class="lcf-input-wrapper">
                                <i class="fa fa-at lcf-input-icon"></i>
                                <input type="email" id="cr_email" name="email" class="lcf-control" placeholder="you@example.com" required>
                            </div>
                        </div>
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="cr_coursename"><i class="fa fa-book"></i> Course Name *</label>
                            <div class="lcf-input-wrapper">
                                <i class="fa fa-bookmark lcf-input-icon"></i>
                                <input type="text" id="cr_coursename" name="course_name" class="lcf-control" placeholder="Desired course title" required>
                            </div>
                        </div>
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="cr_desc"><i class="fa fa-align-left"></i> Course Description *</label>
                            <textarea id="cr_desc" name="course_description" rows="4" class="lcf-control lcf-textarea" placeholder="Describe the course topics or goals..." required></textarea>
                        </div>
                        <button type="submit" class="lcf-btn"><i class="fa fa-paper-plane"></i> Submit Course Request</button>
                    </form>
                </div>';

            case 'support':
                return '
                <div class="lcf-card">
                    <div class="lcf-card-header">
                        <i class="fa fa-life-ring"></i>
                        <h3 class="lcf-card-title">Support Request</h3>
                    </div>
                    <form action="' . s($action) . '" method="post" class="lcf-form">
                        <input type="hidden" name="sesskey" value="' . s($sesskey) . '">
                        <input type="hidden" name="returnurl" value="' . s($returnurl) . '">
                        <input type="hidden" name="website_hp" value="">
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="sr_name"><i class="fa fa-user"></i> Name *</label>
                            <div class="lcf-input-wrapper">
                                <i class="fa fa-user lcf-input-icon"></i>
                                <input type="text" id="sr_name" name="name" class="lcf-control" placeholder="Your full name" required>
                            </div>
                        </div>
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="sr_email"><i class="fa fa-envelope"></i> Email Address *</label>
                            <div class="lcf-input-wrapper">
                                <i class="fa fa-at lcf-input-icon"></i>
                                <input type="email" id="sr_email" name="email" class="lcf-control" placeholder="you@example.com" required>
                            </div>
                        </div>
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="sr_category"><i class="fa fa-list"></i> Issue Category *</label>
                            <div class="lcf-input-wrapper">
                                <i class="fa fa-folder-open lcf-input-icon"></i>
                                <select id="sr_category" name="subject" class="lcf-control" required>
                                    <option value="Technical Support">Technical Support</option>
                                    <option value="Login / Account Issue">Login / Account Issue</option>
                                    <option value="Course Access">Course Access</option>
                                    <option value="Billing / Enrolment">Billing / Enrolment</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="sr_specific"><i class="fa fa-tag"></i> Specific Subject *</label>
                            <div class="lcf-input-wrapper">
                                <i class="fa fa-pen lcf-input-icon"></i>
                                <input type="text" id="sr_specific" name="specific_subject" class="lcf-control" placeholder="Brief summary of the issue" required>
                            </div>
                        </div>
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="sr_url"><i class="fa fa-link"></i> Related Page URL</label>
                            <div class="lcf-input-wrapper">
                                <i class="fa fa-globe lcf-input-icon"></i>
                                <input type="url" id="sr_url" name="url" class="lcf-control" placeholder="https://...">
                            </div>
                        </div>
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="sr_message"><i class="fa fa-comment-medical"></i> Message *</label>
                            <textarea id="sr_message" name="message" rows="5" class="lcf-control lcf-textarea" placeholder="Provide full details so our team can assist you..." required></textarea>
                        </div>
                        <button type="submit" class="lcf-btn"><i class="fa fa-headset"></i> Request Support</button>
                    </form>
                </div>';

            case 'checkin':
                if (!isloggedin() || isguestuser()) {
                    return '<div class="alert alert-warning"><i class="fa fa-lock"></i> ' . get_string('loginrequired_form', 'local_contactform') . '</div>';
                }
                return '
                <form action="' . s($action) . '" method="post" style="display:inline-block;">
                    <input type="hidden" name="sesskey" value="' . s($sesskey) . '">
                    <input type="hidden" name="returnurl" value="' . s($returnurl) . '">
                    <input type="hidden" name="subject" value="Course Check-In">
                    <input type="hidden" name="course" value="' . s($coursename) . '">
                    <input type="hidden" name="status" value="User checked in.">
                    <button type="submit" class="lcf-btn lcf-btn-checkin"><i class="fa fa-circle-check fa-check-circle"></i> I'm here!</button>
                </form>';

            case 'contactus':
            default:
                return '
                <div class="lcf-card">
                    <div class="lcf-card-header">
                        <i class="fa fa-envelope-open-text"></i>
                        <h3 class="lcf-card-title">Contact Us</h3>
                    </div>
                    <form action="' . s($action) . '" method="post" class="lcf-form">
                        <input type="hidden" name="sesskey" value="' . s($sesskey) . '">
                        <input type="hidden" name="returnurl" value="' . s($returnurl) . '">
                        <input type="hidden" name="website_hp" value="">
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="cf_name"><i class="fa fa-user"></i> Name *</label>
                            <div class="lcf-input-wrapper">
                                <i class="fa fa-user lcf-input-icon"></i>
                                <input type="text" id="cf_name" name="name" class="lcf-control" placeholder="Your full name" required>
                            </div>
                        </div>
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="cf_email"><i class="fa fa-envelope"></i> Email Address *</label>
                            <div class="lcf-input-wrapper">
                                <i class="fa fa-at lcf-input-icon"></i>
                                <input type="email" id="cf_email" name="email" class="lcf-control" placeholder="you@example.com" required>
                            </div>
                        </div>
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="cf_subject"><i class="fa fa-tag"></i> Subject *</label>
                            <div class="lcf-input-wrapper">
                                <i class="fa fa-heading lcf-input-icon"></i>
                                <input type="text" id="cf_subject" name="subject" class="lcf-control" placeholder="How can we help?" required>
                            </div>
                        </div>
                        <div class="lcf-form-group">
                            <label class="lcf-label" for="cf_message"><i class="fa fa-comment"></i> Message *</label>
                            <textarea id="cf_message" name="message" rows="5" class="lcf-control lcf-textarea" placeholder="Write your message here..." required></textarea>
                        </div>
                        <button type="submit" class="lcf-btn"><i class="fa fa-paper-plane"></i> Send Message</button>
                    </form>
                </div>';
        }
    }
}
