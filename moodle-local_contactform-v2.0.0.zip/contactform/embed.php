<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Chromeless Embed Endpoint & Interactive Embed Code Generator.
 *
 * @package    local_contactform
 * @copyright  2026 Mr Waseem <waseemuxui@gmail.com> (https://sitefixstudio.com)
 * @author     Mr Waseem | WhatsApp: +923341122126
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

$type      = optional_param('type', 'contactus', PARAM_ALPHA);
$generator = optional_param('generator', 0, PARAM_BOOL);

$PAGE->set_context(context_system::instance());
$PAGE->set_url(new moodle_url('/local/contactform/embed.php', ['type' => $type]));
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('pluginname', 'local_contactform'));

if (get_config('local_contactform', 'allowexternalembed')) {
    @header_remove('X-Frame-Options');
}

echo $OUTPUT->header();
echo local_contactform_get_customizer_css();

// If admin opens ?generator=1, show interactive Embed Snippet Generator alongside live preview.
if ($generator && is_siteadmin()) {
    $embedurl = (new moodle_url('/local/contactform/embed.php', ['type' => $type]))->out(false);
    $iframecode = '<iframe src="' . $embedurl . '" width="100%" height="580" style="border:none; overflow:hidden;" loading="lazy"></iframe>';
    echo '<div class="lcf-card" style="margin-bottom:1.5rem; background:#f8fafc;">';
    echo '<h4><i class="fa fa-code"></i> Embed Code Generator (Admin Preview)</h4>';
    echo '<p>Select a form template to preview and copy its iframe embed code or direct URL:</p>';
    echo '<div style="display:flex; gap:0.5rem; flex-wrap:wrap; margin-bottom:1rem;">';
    $types = ['contactus' => 'Contact Us', 'support' => 'Support Request', 'courserequest' => 'Course Request', 'quickquestion' => 'Quick Question', 'checkin' => 'Check-In Button'];
    foreach ($types as $key => $label) {
        $u = new moodle_url('/local/contactform/embed.php', ['type' => $key, 'generator' => 1]);
        $active = ($type === $key) ? 'style="background:#0f172a;"' : '';
        echo '<a href="' . $u->out() . '" class="lcf-btn" ' . $active . '>' . s($label) . '</a>';
    }
    echo '</div>';
    echo '<strong>1. Direct Iframe Embed Code (Any Moodle Page, Block, or External Website):</strong>';
    echo '<div class="lcf-embed-code-box">' . s($iframecode) . '</div>';
    echo '</div>';
}

$returnurl = (new moodle_url('/local/contactform/embed.php', ['type' => $type]))->out(false);
echo \local_contactform\processor::render_template($type, $returnurl);

// Auto-resize postMessage helper for parent frames.
echo "<script>
window.addEventListener('load', function() {
    var height = document.body.scrollHeight;
    window.parent.postMessage({ type: 'lcfResize', height: height }, '*');
});
</script>";

echo $OUTPUT->footer();
