<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * English language strings for local_contactform.
 *
 * @package    local_contactform
 * @copyright  2026 Mr Waseem <waseemuxui@gmail.com> (https://sitefixstudio.com)
 * @author     Mr Waseem | WhatsApp: +923341122126
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Contact Form Processor';

// Developer Info.
$string['developerinfo'] = 'Developer & Support Information';
$string['developerinfo_desc'] = '<div style="background:#f8fafc; border-left:4px solid #0f6cbf; padding:12px 16px; border-radius:4px;">
<strong>Developer:</strong> Mr Waseem<br>
<strong>Email:</strong> <a href="mailto:waseemuxui@gmail.com">waseemuxui@gmail.com</a><br>
<strong>Website:</strong> <a href="https://sitefixstudio.com" target="_blank" rel="noopener">sitefixstudio.com</a><br>
<strong>WhatsApp Support:</strong> <a href="https://wa.me/923341122126" target="_blank" rel="noopener">+923341122126</a>
</div>';

// General Settings.
$string['generalheading'] = 'General & Routing Settings';
$string['generalheading_desc'] = 'Configure email destination routing, login policies, and Font Awesome icon libraries.';
$string['recipientemail'] = 'Custom Support Email';
$string['recipientemail_desc'] = 'Override the default site support email. Leave blank to use Moodle's support email or primary system administrator.';
$string['requirelogin'] = 'Require Login for All Forms';
$string['requirelogin_desc'] = 'If enabled, only authenticated users can submit forms.';
$string['enablefontawesome'] = 'Load Font Awesome 6 Icons';
$string['enablefontawesome_desc'] = 'Ensures Font Awesome 6 icons render inside forms even if your Moodle theme does not bundle them.';

// Visual Customizer Settings.
$string['customizerheading'] = 'Visual Customizer & CSS Styling';
$string['customizerheading_desc'] = 'Customize form colors, backgrounds, border radius, card shadows, and custom CSS rules without editing code.';
$string['primarycolor'] = 'Primary Theme / Button Color';
$string['primarycolor_desc'] = 'Used for form icons, input focus rings, and submit buttons (Default: #0f6cbf).';
$string['formbgcolor'] = 'Form Card Background Color';
$string['formbgcolor_desc'] = 'Background color of the form container card (Default: #ffffff).';
$string['textcolor'] = 'Form Text & Label Color';
$string['textcolor_desc'] = 'Primary text color for headings, labels, and inputs (Default: #1e293b).';
$string['borderradius'] = 'Border Radius';
$string['borderradius_desc'] = 'Corner roundness for cards, inputs, and buttons (e.g., 8px, 12px, 0px).';
$string['enablecardshadow'] = 'Enable Card Drop Shadow';
$string['enablecardshadow_desc'] = 'Applies a subtle modern elevation shadow around form cards.';
$string['customcss'] = 'Custom CSS Rules';
$string['customcss_desc'] = 'Add custom CSS overrides targeting <code>.lcf-card</code>, <code>.lcf-btn</code>, or <code>.lcf-control</code>.';

// Embed Settings.
$string['embedheading'] = 'Embed & Shortcode Support';
$string['embedheading_desc'] = 'Embed any form inside Moodle pages, blocks, or external websites using our chromeless embed endpoint.<br>
<a href="{$a}?generator=1" target="_blank" class="btn btn-secondary btn-sm mt-2"><i class="fa fa-code"></i> Open Interactive Embed Code Generator</a>';
$string['allowexternalembed'] = 'Allow External Iframe Embedding';
$string['allowexternalembed_desc'] = 'Removes X-Frame-Options restrictions on embed.php so forms can be embedded on external domains.';

// Notifications & Messages.
$string['emailsubjectprefix'] = '[{$a}] Form Submission: ';
$string['thankyou'] = 'Thank you! Your message has been sent.';
$string['error_sending'] = 'There was an error sending your message. Please try again later.';
$string['loginrequired_form'] = 'Please log in to view and submit this form.';
$string['privacy:metadata'] = 'The Contact Form Processor plugin does not store personal user data in the Moodle database; it forwards submitted form fields directly via email to the site support address or system administrator.';
