# Moodle Contact Form Processor (`local_contactform`)

A lightweight, customizable Contact Form Processor plugin for Moodle with **Font Awesome 6 icon support**, a built-in **Visual Customizer**, **Iframe/JS Embed support**, and **FilterCodes `{form...}` template compatibility**.

---

## Author & Developer Support
* **Developer:** Mr Waseem
* **Email:** [waseemuxui@gmail.com](mailto:waseemuxui@gmail.com)
* **Website:** [https://sitefixstudio.com](https://sitefixstudio.com)
* **WhatsApp:** [+923341122126](https://wa.me/923341122126)

---

## Key Features
1. **Smart Email Routing:** Automatically delivers form submissions to your configured Custom Support Email, Moodle's `$CFG->supportemail`, or the Primary System Administrator.
2. **Font Awesome 6 Icon Support:** Every form field, header, and submit button includes semantic Font Awesome icons (`fa-user`, `fa-envelope`, `fa-paper-plane`, `fa-life-ring`, `fa-graduation-cap`, etc.).
3. **Built-in Visual Customizer:** Customize primary brand color, card background color, text color, border radius, drop shadow, and custom CSS directly from **Site Administration > Plugins > Local plugins > Contact Form Processor**.
4. **Chromeless Embed & Generator (`embed.php`):** Embed any of the 5 pre-built templates (`contactus`, `support`, `courserequest`, `quickquestion`, `checkin`) via `<iframe>` inside Moodle Pages, Labels, Blocks, or external websites.
5. **Anti-Spam & CSRF Protection:** Built-in Moodle `sesskey` verification and honeypot field filtering (`website_hp`).
6. **GDPR / Privacy API Compliant:** Implements `\core_privacy\local\metadata
ull_provider` as required for Moodle Plugins Directory approval.

---

## Installation
1. Upload the `contactform` folder to `/local/contactform` in your Moodle directory, or upload the ZIP package via **Site administration > Plugins > Install plugins**.
2. Visit **Site administration > Notifications** to complete the installation.
3. Configure colors, Font Awesome support, and email routing under **Site administration > Plugins > Local plugins > Contact Form Processor**.
