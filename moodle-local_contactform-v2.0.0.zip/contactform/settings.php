<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Admin settings and Visual Customizer for Contact Form Processor.
 *
 * @package    local_contactform
 * @copyright  2026 Mr Waseem <waseemuxui@gmail.com> (https://sitefixstudio.com)
 * @author     Mr Waseem | WhatsApp: +923341122126
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_contactform', get_string('pluginname', 'local_contactform'));

    // Developer & Support Info Banner.
    $settings->add(new admin_setting_heading(
        'local_contactform/developerinfo',
        get_string('developerinfo', 'local_contactform'),
        get_string('developerinfo_desc', 'local_contactform')
    ));

    // General Settings Section.
    $settings->add(new admin_setting_heading(
        'local_contactform/generalheading',
        get_string('generalheading', 'local_contactform'),
        get_string('generalheading_desc', 'local_contactform')
    ));

    $settings->add(new admin_setting_configtext(
        'local_contactform/recipientemail',
        get_string('recipientemail', 'local_contactform'),
        get_string('recipientemail_desc', 'local_contactform'),
        '',
        PARAM_EMAIL
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_contactform/requirelogin',
        get_string('requirelogin', 'local_contactform'),
        get_string('requirelogin_desc', 'local_contactform'),
        0
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_contactform/enablefontawesome',
        get_string('enablefontawesome', 'local_contactform'),
        get_string('enablefontawesome_desc', 'local_contactform'),
        1
    ));

    // Visual Customizer Section.
    $settings->add(new admin_setting_heading(
        'local_contactform/customizerheading',
        get_string('customizerheading', 'local_contactform'),
        get_string('customizerheading_desc', 'local_contactform')
    ));

    $settings->add(new admin_setting_configcolourpicker(
        'local_contactform/primarycolor',
        get_string('primarycolor', 'local_contactform'),
        get_string('primarycolor_desc', 'local_contactform'),
        '#0f6cbf'
    ));

    $settings->add(new admin_setting_configcolourpicker(
        'local_contactform/formbgcolor',
        get_string('formbgcolor', 'local_contactform'),
        get_string('formbgcolor_desc', 'local_contactform'),
        '#ffffff'
    ));

    $settings->add(new admin_setting_configcolourpicker(
        'local_contactform/textcolor',
        get_string('textcolor', 'local_contactform'),
        get_string('textcolor_desc', 'local_contactform'),
        '#1e293b'
    ));

    $settings->add(new admin_setting_configtext(
        'local_contactform/borderradius',
        get_string('borderradius', 'local_contactform'),
        get_string('borderradius_desc', 'local_contactform'),
        '8px',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_contactform/enablecardshadow',
        get_string('enablecardshadow', 'local_contactform'),
        get_string('enablecardshadow_desc', 'local_contactform'),
        1
    ));

    $settings->add(new admin_setting_configtextarea(
        'local_contactform/customcss',
        get_string('customcss', 'local_contactform'),
        get_string('customcss_desc', 'local_contactform'),
        '',
        PARAM_RAW
    ));

    // Embed & Generator Section.
    $embedurl = new moodle_url('/local/contactform/embed.php');
    $settings->add(new admin_setting_heading(
        'local_contactform/embedheading',
        get_string('embedheading', 'local_contactform'),
        get_string('embedheading_desc', 'local_contactform', $embedurl->out())
    ));

    $settings->add(new admin_setting_configcheckbox(
        'local_contactform/allowexternalembed',
        get_string('allowexternalembed', 'local_contactform'),
        get_string('allowexternalembed_desc', 'local_contactform'),
        1
    ));

    $ADMIN->add('localplugins', $settings);
}
