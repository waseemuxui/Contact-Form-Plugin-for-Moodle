<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Form submission processor and standalone view endpoint.
 *
 * @package    local_contactform
 * @copyright  2026 Mr Waseem <waseemuxui@gmail.com> (https://sitefixstudio.com)
 * @author     Mr Waseem | WhatsApp: +923341122126
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

$type = optional_param('type', 'contactus', PARAM_ALPHA);

$PAGE->set_context(context_system::instance());
$PAGE->set_url(new moodle_url('/local/contactform/index.php', ['type' => $type]));
$PAGE->set_title(get_string('pluginname', 'local_contactform'));
$PAGE->set_heading($SITE->fullname);

if (get_config('local_contactform', 'requirelogin')) {
    require_login();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_sesskey();

    $returnurl = optional_param('returnurl', $CFG->wwwroot, PARAM_LOCALURL);
    if (empty($returnurl)) {
        $returnurl = new moodle_url('/local/contactform/index.php', ['type' => $type]);
    }

    $success = \local_contactform\processor::send_submission($_POST);

    if ($success) {
        redirect($returnurl, get_string('thankyou', 'local_contactform'), null, \core\output
otification::NOTIFY_SUCCESS);
    } else {
        redirect($returnurl, get_string('error_sending', 'local_contactform'), null, \core\output
otification::NOTIFY_ERROR);
    }
}

echo $OUTPUT->header();
echo local_contactform_get_customizer_css();
echo \local_contactform\processor::render_template($type);
echo $OUTPUT->footer();
