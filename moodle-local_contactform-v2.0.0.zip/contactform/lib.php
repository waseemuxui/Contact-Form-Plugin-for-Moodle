<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Library callbacks for injecting Customizer CSS and Font Awesome support.
 *
 * @package    local_contactform
 * @copyright  2026 Mr Waseem <waseemuxui@gmail.com> (https://sitefixstudio.com)
 * @author     Mr Waseem | WhatsApp: +923341122126
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Generates dynamic CSS variables and custom CSS rules from plugin settings.
 *
 * @return string HTML style block
 */
function local_contactform_get_customizer_css(): string {
    $primarycolor = get_config('local_contactform', 'primarycolor') ?: '#0f6cbf';
    $formbgcolor  = get_config('local_contactform', 'formbgcolor') ?: '#ffffff';
    $textcolor    = get_config('local_contactform', 'textcolor') ?: '#1e293b';
    $borderradius = get_config('local_contactform', 'borderradius') ?: '8px';
    $shadow       = get_config('local_contactform', 'enablecardshadow');
    $customcss    = get_config('local_contactform', 'customcss') ?: '';

    $shadowval = ($shadow === '0') ? 'none' : '0 10px 25px -5px rgba(0, 0, 0, 0.08), 0 8px 10px -6px rgba(0, 0, 0, 0.04)';

    $css = ":root {
        --lcf-primary: {$primarycolor};
        --lcf-bg: {$formbgcolor};
        --lcf-text: {$textcolor};
        --lcf-radius: {$borderradius};
        --lcf-shadow: {$shadowval};
    }
" . $customcss;

    return "<style id="local-contactform-customizer">
" . $css . "
</style>
";
}

/**
 * Hook before standard HTML head is rendered across Moodle pages.
 *
 * @return string
 */
function local_contactform_before_standard_html_head(): string {
    $output = local_contactform_get_customizer_css();
    if (get_config('local_contactform', 'enablefontawesome')) {
        $output .= '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />' . "
";
    }
    return $output;
}
